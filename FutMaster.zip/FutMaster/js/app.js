// app.js - FutMaster v3.3 (final)
// FIREBASE CONFIG (já preenchido - substitua se mudar)
const firebaseConfig = {
  apiKey: "AIzaSyAuKyiDOpKsq11iO0c7v8NvQYqVdbZr4Ko",
  authDomain: "futuriasmaster.firebaseapp.com",
  databaseURL: "https://uriasfutmaster2-default-rtdb.firebaseio.com/",
  projectId: "futuriasmaster",
  storageBucket: "futuriasmaster.firebasestorage.app",
  messagingSenderId: "698635901166",
  appId: "1:698635901166:web:670975316797b14eb07bff",
  measurementId: "G-XLTG46ZKZP"
};

const KEY = 'futpro_v3_3_state';
let state = { playersQueue: [], teams: [], payments: {}, clearPaymentsOnLoad: false, timerSeconds: 7*60, soundOn: true };

function save(){ localStorage.setItem(KEY, JSON.stringify(state)); if(window.__firebaseEnabled) pushStateToFirebase(); }
function load(){ const v=localStorage.getItem(KEY); if(v){ try{ const p=JSON.parse(v); state = {...state, ...p}; }catch(e){console.warn(e);} } if(state.clearPaymentsOnLoad) state.payments={}; }
function formatTime(s){ const m=Math.floor(s/60).toString().padStart(2,'0'); const sec=(s%60).toString().padStart(2,'0'); return ${m}:${sec}; }
function shuffle(arr){ for(let i=arr.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [arr[i],arr[j]]=[arr[j],arr[i]]; } }

let queueList, countQueue, teamsContainer, countTeams, paymentsList, timerDisplay, chkClearOnLoad, chkSound, inputPlayer, btnAdd;

function initDOMRefs(){
  queueList = document.getElementById('queueList');
  countQueue = document.getElementById('countQueue');
  teamsContainer = document.getElementById('teamsContainer');
  countTeams = document.getElementById('countTeams');
  paymentsList = document.getElementById('paymentsList');
  timerDisplay = document.getElementById('timerDisplay');
  chkClearOnLoad = document.getElementById('chkClearOnLoad');
  chkSound = document.getElementById('chkSound');
  inputPlayer = document.getElementById('inputPlayer');
  btnAdd = document.getElementById('btnAdd');
}

function renderAll(){ renderQueue(); renderTeams(); renderPayments(); timerDisplay.textContent = formatTime(state.timerSeconds); chkClearOnLoad.checked = !!state.clearPaymentsOnLoad; chkSound.checked = !!state.soundOn; save(); }

function renderQueue(){
  queueList.innerHTML='';
  state.playersQueue.forEach((name, idx)=>{
    const div = document.createElement('div'); div.className='row';
    div.draggable = true;
    div.dataset.origin = 'queue'; div.dataset.idx = idx;
    div.innerHTML = `<div class="pos">${idx+1}</div><div class="name">${escapeHtml(name)}</div><div class="actions">
      <button class="tiny edit-queue" data-idx="${idx}">✏️</button>
      <button class="tiny up-queue" data-idx="${idx}">🔼</button>
      <button class="tiny down-queue" data-idx="${idx}">🔽</button>
      <button class="tiny move-to-team" data-idx="${idx}">↪️ Mover</button>
      <button class="tiny remove-queue" data-idx="${idx}">🗑️</button>
    </div>`;
    div.addEventListener('dragstart', (e)=> onDragStart(e, {type:'queue', idx}));
    queueList.appendChild(div);
  });
  countQueue.textContent = state.playersQueue.length;
}

function renderTeams(){
  teamsContainer.innerHTML='';
  state.teams.forEach((team, tIndex)=>{
    const teamLabel = String.fromCharCode(65 + tIndex);
    let statusLabel = '', statusClass='';
    if(tIndex===0){ statusLabel='Jogando'; statusClass='status-playing-1'; }
    else if(tIndex===1){ statusLabel='Jogando'; statusClass='status-playing-2'; }
    else if(tIndex===2){ statusLabel='Próximo'; statusClass='status-next'; }
    else { statusLabel='Aguardando'; statusClass='status-waiting'; }
    const card = document.createElement('div'); card.className='team-card';
    const playersHtml = team.map((p, idx)=> `<div class="player-item" draggable="true" data-origin="team" data-team="${tIndex}" data-idx="${idx}" >
      <div class="player-role">${idx+1}</div><div class="player-name">${escapeHtml(p)}</div>
      <div style="display:flex;gap:6px">
        <button class="tiny edit-team" data-team="${tIndex}" data-idx="${idx}">✏️</button>
        <button class="tiny move-up-team" data-team="${tIndex}" data-idx="${idx}">🔼</button>
        <button class="tiny move-down-team" data-team="${tIndex}" data-idx="${idx}">🔽</button>
        <button class="tiny move-player" data-team="${tIndex}" data-idx="${idx}">↔️ Mover</button>
        <button class="tiny remove-team-player" data-team="${tIndex}" data-idx="${idx}">⤵️ Enviar à fila</button>
      </div></div>`).join('') || '<div class="small">Vazio</div>';
    card.innerHTML = `<div class="team-title"><div class="team-heading ${statusClass}">Time ${teamLabel} — <span class="team-status">${statusLabel}</span></div><div class="small">${team.length}/5</div></div><div class="team-players" data-teamindex="${tIndex}" ondragover="allowDrop(event)" ondrop="onDropToTeam(event, ${tIndex})">${playersHtml}</div>
      <div style="display:flex;gap:8px;margin-top:8px;align-items:center">
        <button class="tiny btn-pull-next" data-team="${tIndex}">Puxar próximo (5)</button>
        <button class="tiny btn-loser" data-team="${tIndex}">Time ${teamLabel} perdeu</button>
        <button class="tiny btn-move-up-card" data-team="${tIndex}">⬆️ Subir time</button>
        <button class="tiny btn-move-down-card" data-team="${tIndex}">⬇️ Descer time</button>
        <button class="tiny btn-move-to-pos" data-team="${tIndex}">↕️ Mover para posição</button>
      </div>`;
    teamsContainer.appendChild(card);
  });
  document.querySelectorAll('.player-item').forEach(el=>{
    el.addEventListener('dragstart', (e)=>{
      const origin = el.dataset.origin; const team = el.dataset.team; const idx = el.dataset.idx;
      onDragStart(e, {type:'team', team: Number(team), idx: Number(idx)});
    });
  });
  countTeams.textContent = state.teams.length;
}

function escapeHtml(s=''){ return (''+s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function escapeAttr(s=''){ return (''+s).replace(/"/g,'&quot;'); }
function uniquePlayers(){ const s=new Set(); state.playersQueue.forEach(p=>s.add(p)); state.teams.flat().forEach(p=>s.add(p)); return Array.from(s); }

let currentDrag = null;